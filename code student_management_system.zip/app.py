from flask import Flask, render_template, request, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = "secret123"

def init_db():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        roll TEXT,
        course TEXT,
        marks INTEGER,
        attendance INTEGER
    )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    if request.form['username'] == "admin" and request.form['password'] == "admin":
        session['admin'] = True
        return redirect('/dashboard')
    return "Invalid Login"

@app.route('/dashboard')
def dashboard():
    if 'admin' not in session:
        return redirect('/')

    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()
    conn.close()

    return render_template('dashboard.html', students=students)

@app.route('/add', methods=['POST'])
def add():
    data = request.form
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO students (name,roll,course,marks,attendance) VALUES (?,?,?,?,?)",
                   (data['name'], data['roll'], data['course'], data['marks'], data['attendance']))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/delete/<int:id>')
def delete(id):
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM students WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
